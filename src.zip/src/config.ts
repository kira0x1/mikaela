export const prefix = '.';

const dev_token = 'NTk2MTA3NjEyODE5NTU0MzA1.XcHipg.Z1cfJe50Jri3aRygD5CXwwc8PSI';
const mikaela_token = 'NTg1ODc0MzM3NjE4NDYwNjcy.XhGApA.Pvm_Gnj3CnjL_Fmg1XrNbZ8LE0k';
export const token = mikaela_token;

export const youTubeKey = 'AIzaSyAQBRTOfd9yTAL6uP-9wab_h3GnuUklk-g';

export const coders_club_id = '585850878532124672';
export const discord_done_left_id = '413059339138629632';

//* 'Discord Done Left' General Text-Channel ID
export const ddl_general_channel_id = '595870992476274688';

export const perms = [
   {
      name: 'admin',
      users: ['177016697117474816'],
   },
];

// Mongodb Config
const user = 'mikaela';
const pass = '7Xh9T0KUGjgHmi6b';
const prodDB = 'mongodb+srv://' + user + ':' + pass + '@cluster0-jcxl4.gcp.mongodb.net/mikaela';
const testDB = 'mongodb://127.0.0.1:27017/local';
export const dbURI = prodDB;