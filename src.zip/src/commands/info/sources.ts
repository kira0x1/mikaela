import { CommandInfo } from '../../classes/CommandInfo';
export const info: CommandInfo = new CommandInfo('Sources', 'Organize and store sources', ['source', 'src'], [], 'list');
