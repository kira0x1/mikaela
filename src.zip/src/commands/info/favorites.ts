import { CommandInfo } from "../../classes/CommandInfo";
export const info: CommandInfo = new CommandInfo("Favorites", "Users favorite songs", ["fav", "f"], [])