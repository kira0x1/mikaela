import { CommandInfo } from "../../classes/CommandInfo";
export const info: CommandInfo = new CommandInfo("Music", "Plays Music", [], [])