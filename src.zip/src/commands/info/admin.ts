import { CommandInfo } from "../../classes/CommandInfo";
export const info: CommandInfo = new CommandInfo("Admin", "Admin Commands", ["sys"], [])