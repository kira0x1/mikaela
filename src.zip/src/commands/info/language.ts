import { CommandInfo } from "../../classes/CommandInfo";
export const info: CommandInfo = new CommandInfo("Language", "Translates, and or detects languages", ['lang'], []);
