import { ICommand } from "../../classes/Command";

export const command: ICommand = {
   name: "AutoQueue",
   description: "Auto Queue's random song's from peoples favorites",
   aliases: ["aq"],
   args: false,

   async execute(message, args) {
       
   },
};
